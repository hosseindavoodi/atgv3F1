This projecet is made by React hooks, javascript, sass and Jest(unit test) also react-tab, bootstrap are added

Also bootstrap.bundle.min.js cdn link is added in index.html

Please copy files on the local folder and run these commands:

### `npm install`

### `npm start`


To run tests this command:

### `npm test`




Or if you needed to install manually:

npm install react-tabs

npm install -g sass

npm install jest --save-dev

npm install react-bootstrap bootstrap




